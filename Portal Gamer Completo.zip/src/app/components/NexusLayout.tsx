import { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router";
import { Search, X, Gamepad2, LogOut, User, ChevronDown } from "lucide-react";
import { allSearchableItems } from "../data/gameData";

interface SearchResult {
  id: string;
  name: string;
  desc: string;
  tag: string;
  section: string;
  genre?: string;
}

interface NexusLayoutProps {
  children: React.ReactNode;
}

export function NexusLayout({ children }: NexusLayoutProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([]);
      setShowResults(false);
      return;
    }
    const q = query.toLowerCase();
    const filtered = allSearchableItems.filter(
      item => item.name.toLowerCase().includes(q) || item.desc.toLowerCase().includes(q) || item.tag.toLowerCase().includes(q)
    ).slice(0, 8);
    setResults(filtered);
    setShowResults(true);
  }, [query]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowResults(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function handleResultClick(item: SearchResult) {
    setQuery("");
    setShowResults(false);
    if (item.genre && ["rpg","fps","esports","terror","estrategia","retro","indie","aventura"].includes(item.genre)) {
      navigate(`/genero/${item.genre}`);
    } else if (item.section === "Hardware") {
      navigate("/pc-gaming");
    }
  }

  const navLinks = [
    { label: "Home", to: "/home" },
    { label: "Hardware", to: "/pc-gaming" },
    { label: "Consoles", to: "/consoles" },
    { label: "Periféricos", to: "/perifericos" },
    { label: "Jogos", to: "/jogos" },
  ];

  return (
    <div style={{ backgroundColor: "#0f0f13", minHeight: "100vh", color: "#fff" }}>
      <header style={{
        backgroundColor: "#16161f",
        padding: "0 5%",
        borderBottom: "2px solid #00ff88",
        position: "sticky",
        top: 0,
        zIndex: 100,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: "64px",
        gap: "16px",
      }}>
        {/* Logo */}
        <Link to="/home" style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: "8px" }}>
          <Gamepad2 style={{ color: "#00ff88", width: 28, height: 28 }} />
          <span style={{ fontSize: "20px", fontWeight: 800, letterSpacing: "2px", color: "#fff", textTransform: "uppercase" }}>
            Nexus<span style={{ color: "#00ff88" }}>Gaming</span>
          </span>
        </Link>

        {/* Search Bar */}
        <div ref={searchRef} style={{ flex: 1, maxWidth: "500px", position: "relative" }}>
          <div style={{ position: "relative" }}>
            <Search style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "#666", width: 18, height: 18 }} />
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onFocus={() => results.length > 0 && setShowResults(true)}
              placeholder="Buscar jogos, hardware, periféricos..."
              style={{
                width: "100%",
                padding: "9px 12px 9px 38px",
                backgroundColor: "#0f0f13",
                border: "1px solid #232330",
                borderRadius: "8px",
                color: "#fff",
                fontSize: "14px",
                outline: "none",
                transition: "border-color 0.2s",
              }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = "#00ff88")}
              onMouseLeave={e => (e.currentTarget.style.borderColor = query ? "#00ff88" : "#232330")}
            />
            {query && (
              <button onClick={() => { setQuery(""); setShowResults(false); }} style={{ position: "absolute", right: "10px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "#666" }}>
                <X style={{ width: 16, height: 16 }} />
              </button>
            )}
          </div>
          {showResults && results.length > 0 && (
            <div style={{
              position: "absolute",
              top: "calc(100% + 6px)",
              left: 0,
              right: 0,
              backgroundColor: "#16161f",
              border: "1px solid #232330",
              borderRadius: "8px",
              overflow: "hidden",
              boxShadow: "0 8px 24px rgba(0,0,0,0.6)",
              zIndex: 200,
            }}>
              {results.map(item => (
                <div
                  key={item.id}
                  onClick={() => handleResultClick(item)}
                  style={{
                    padding: "10px 16px",
                    cursor: "pointer",
                    borderBottom: "1px solid #232330",
                    display: "flex",
                    alignItems: "flex-start",
                    gap: "10px",
                  }}
                  onMouseEnter={e => (e.currentTarget.style.backgroundColor = "#1e1e2a")}
                  onMouseLeave={e => (e.currentTarget.style.backgroundColor = "transparent")}
                >
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "14px", color: "#fff", marginBottom: "2px" }}>{item.name}</div>
                    <div style={{ fontSize: "11px", color: "#666" }}>{item.section}</div>
                  </div>
                  <span style={{ backgroundColor: "#00ff88", color: "#000", fontSize: "10px", fontWeight: 700, padding: "2px 6px", borderRadius: "4px", whiteSpace: "nowrap" }}>{item.tag}</span>
                </div>
              ))}
              <div style={{ padding: "8px 16px", fontSize: "12px", color: "#666", textAlign: "center" }}>
                {results.length} resultado(s) para "{query}"
              </div>
            </div>
          )}
          {showResults && query.length >= 2 && results.length === 0 && (
            <div style={{
              position: "absolute",
              top: "calc(100% + 6px)",
              left: 0,
              right: 0,
              backgroundColor: "#16161f",
              border: "1px solid #232330",
              borderRadius: "8px",
              padding: "16px",
              textAlign: "center",
              color: "#666",
              fontSize: "14px",
              zIndex: 200,
            }}>
              Nenhum resultado para "{query}"
            </div>
          )}
        </div>

        {/* Nav Links (desktop) */}
        <nav style={{ display: "flex", gap: "4px", alignItems: "center" }}>
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              style={{
                color: "#b3b3b3",
                textDecoration: "none",
                fontSize: "13px",
                padding: "6px 10px",
                borderRadius: "6px",
                transition: "color 0.2s",
                whiteSpace: "nowrap",
              }}
              onMouseEnter={e => { e.currentTarget.style.color = "#00ff88"; }}
              onMouseLeave={e => { e.currentTarget.style.color = "#b3b3b3"; }}
            >
              {link.label}
            </Link>
          ))}
          <Link to="/" style={{ marginLeft: "8px", color: "#666", padding: "6px" }} title="Sair">
            <LogOut style={{ width: 18, height: 18 }} />
          </Link>
        </nav>
      </header>

      <main>{children}</main>

      <footer style={{
        backgroundColor: "#060608",
        textAlign: "center",
        padding: "30px 20px",
        fontSize: "14px",
        color: "#666",
        borderTop: "1px solid #16161f",
        marginTop: "60px",
      }}>
        <p style={{ marginBottom: "8px" }}>
          <span style={{ color: "#00ff88", fontWeight: 700 }}>NexusGaming</span> © 2026 — O Portal Definitivo do Universo Gamer
        </p>
        <p style={{ fontSize: "12px" }}>Hardware • Software • Jogos • Análises • Comunidade • E-Sports</p>
      </footer>
    </div>
  );
}
