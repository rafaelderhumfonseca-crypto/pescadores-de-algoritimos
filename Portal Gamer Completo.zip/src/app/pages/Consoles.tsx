import { useState } from "react";
import { Link } from "react-router";
import { Star, ShoppingCart, Gamepad2 } from "lucide-react";
import { NexusLayout } from "../components/NexusLayout";

const consoles = [
  { nome: "PlayStation 5", desc: "Console de última geração da Sony com SSD ultra-rápido e DualSense.", preco: "R$ 4.499,00", rating: 4.9, emoji: "🎮", tag: "Sony", cor: "#003791" },
  { nome: "Xbox Series X", desc: "O console mais potente da Microsoft com Quick Resume e Game Pass.", preco: "R$ 4.299,00", rating: 4.8, emoji: "🟢", tag: "Microsoft", cor: "#107c10" },
  { nome: "Nintendo Switch OLED", desc: "Portátil e versátil com tela OLED vibrante de 7 polegadas.", preco: "R$ 2.799,00", rating: 4.7, emoji: "🔴", tag: "Nintendo", cor: "#e4000f" },
  { nome: "PlayStation 5 Slim", desc: "Design compacto mantendo toda a potência do PS5 original.", preco: "R$ 3.999,00", rating: 4.8, emoji: "🎮", tag: "Sony", cor: "#003791" },
  { nome: "Xbox Series S", desc: "Console compacto all-digital perfeito para Game Pass.", preco: "R$ 2.499,00", rating: 4.6, emoji: "🟢", tag: "Microsoft", cor: "#107c10" },
  { nome: "Steam Deck OLED", desc: "PC portátil com toda a biblioteca Steam na palma da mão.", preco: "R$ 3.499,00", rating: 4.9, emoji: "🖥️", tag: "Valve", cor: "#1b2838" },
];

const exclusivos = [
  { console: "PlayStation", jogos: ["Spider-Man 2", "God of War: Ragnarök", "Ghost of Yōtei", "Horizon Forbidden West"] },
  { console: "Xbox / PC", jogos: ["Halo Infinite", "Forza Motorsport", "Starfield", "Indiana Jones"] },
  { console: "Nintendo", jogos: ["The Legend of Zelda", "Mario Kart 8 Deluxe", "Pokémon Scarlet", "Metroid Prime 4"] },
];

const subcategorias = ["PlayStation", "Xbox", "Nintendo Switch", "Portáteis", "Exclusivos PS5", "Exclusivos Xbox", "Retrocompatibilidade", "Controles", "Acessórios"];

export default function Consoles() {
  const [hovered, setHovered] = useState<string | null>(null);
  const [activeSub, setActiveSub] = useState("PlayStation");

  return (
    <NexusLayout>
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "40px 20px" }}>
        <div style={{ marginBottom: "32px", display: "flex", alignItems: "center", gap: "12px" }}>
          <Gamepad2 style={{ color: "#00ff88", width: 32, height: 32 }} />
          <div>
            <h2 style={{ fontSize: "32px", fontWeight: 800, color: "#fff", borderLeft: "4px solid #00ff88", paddingLeft: "14px" }}>
              Consoles
            </h2>
            <p style={{ color: "#666", fontSize: "13px", paddingLeft: "18px" }}>PlayStation • Xbox • Nintendo Switch • Portáteis</p>
          </div>
        </div>

        {/* Filtros */}
        <div style={{ marginBottom: "36px", display: "flex", flexWrap: "wrap", gap: "8px" }}>
          {subcategorias.map(sub => (
            <button key={sub} onClick={() => setActiveSub(sub)} style={{
              padding: "7px 16px",
              backgroundColor: activeSub === sub ? "#00ff88" : "#16161f",
              border: `1px solid ${activeSub === sub ? "#00ff88" : "#232330"}`,
              borderRadius: "20px",
              color: activeSub === sub ? "#000" : "#b3b3b3",
              fontSize: "13px",
              fontWeight: activeSub === sub ? 700 : 400,
              cursor: "pointer",
            }}>
              {sub}
            </button>
          ))}
        </div>

        {/* Grid de Consoles */}
        <div style={{ marginBottom: "8px", color: "#b3b3b3", fontSize: "13px", borderLeft: "4px solid #00ff88", paddingLeft: "12px", marginBottom: "20px" }}>
          <span style={{ color: "#fff", fontWeight: 700, fontSize: "22px" }}>Consoles Disponíveis</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "20px", marginBottom: "60px" }}>
          {consoles.map(console_ => (
            <div key={console_.nome}
              style={{
                backgroundColor: "#16161f",
                border: `1px solid ${hovered === console_.nome ? "#00ff88" : "#232330"}`,
                borderRadius: "10px",
                overflow: "hidden",
                transition: "transform 0.2s, box-shadow 0.2s, border-color 0.2s",
                transform: hovered === console_.nome ? "translateY(-5px)" : "none",
                boxShadow: hovered === console_.nome ? "0 8px 24px rgba(0,255,136,0.25)" : "none",
              }}
              onMouseEnter={() => setHovered(console_.nome)}
              onMouseLeave={() => setHovered(null)}
            >
              <div style={{
                height: "150px",
                background: `linear-gradient(135deg, ${console_.cor}aa, ${console_.cor}33)`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "64px",
              }}>
                {console_.emoji}
              </div>
              <div style={{ padding: "18px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
                  <span style={{ backgroundColor: "#00ff88", color: "#000", fontSize: "10px", fontWeight: 700, padding: "2px 8px", borderRadius: "4px" }}>{console_.tag}</span>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px", color: "#fbbf24", fontSize: "13px" }}>
                    <Star style={{ width: 13, height: 13, fill: "#fbbf24" }} />
                    {console_.rating}
                  </div>
                </div>
                <h3 style={{ color: "#fff", fontSize: "17px", fontWeight: 700, marginBottom: "6px" }}>{console_.nome}</h3>
                <p style={{ color: "#999", fontSize: "13px", lineHeight: 1.5, marginBottom: "14px" }}>{console_.desc}</p>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span style={{ color: "#00ff88", fontSize: "18px", fontWeight: 800 }}>{console_.preco}</span>
                  <button style={{
                    display: "flex", alignItems: "center", gap: "6px",
                    backgroundColor: "#00ff88", color: "#000", border: "none",
                    padding: "8px 16px", borderRadius: "6px", fontSize: "13px", fontWeight: 700, cursor: "pointer",
                  }}>
                    <ShoppingCart style={{ width: 14, height: 14 }} />
                    Comprar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Exclusivos por console */}
        <div style={{ marginBottom: "20px" }}>
          <h2 style={{ fontSize: "24px", fontWeight: 700, color: "#fff", borderLeft: "4px solid #00ff88", paddingLeft: "12px", marginBottom: "20px" }}>
            Exclusivos por Plataforma
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "20px" }}>
            {exclusivos.map(plat => (
              <div key={plat.console} style={{ backgroundColor: "#16161f", border: "1px solid #232330", borderRadius: "10px", padding: "20px" }}>
                <h3 style={{ color: "#00ff88", fontSize: "16px", fontWeight: 700, marginBottom: "12px" }}>{plat.console}</h3>
                {plat.jogos.map(jogo => (
                  <div key={jogo} style={{ padding: "8px 0", borderBottom: "1px solid #232330", color: "#b3b3b3", fontSize: "13px", display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ color: "#00ff88", fontSize: "10px" }}>▶</span>
                    {jogo}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </NexusLayout>
  );
}
