import { useState } from "react";
import { Monitor, Star, ShoppingCart, Cpu, HardDrive, Zap } from "lucide-react";
import { NexusLayout } from "../components/NexusLayout";

const componentes = [
  { nome: "RTX 5080 Super", categoria: "Placa de Vídeo", desc: "A GPU mais potente da NVIDIA para 4K/144fps com Ray Tracing total.", preco: "R$ 6.999,00", rating: 5.0, icon: Monitor, cor: "#76b900" },
  { nome: "AMD Ryzen 9 9950X", categoria: "Processador", desc: "16 cores de nova geração com arquitetura Zen 5.", preco: "R$ 4.899,00", rating: 4.9, icon: Cpu, cor: "#ed1c24" },
  { nome: "RTX 5070 Ti", categoria: "Placa de Vídeo", desc: "Melhor custo-benefício para 4K gaming em 2026.", preco: "R$ 4.499,00", rating: 4.8, icon: Monitor, cor: "#76b900" },
  { nome: "Intel Core Ultra 9 285K", categoria: "Processador", desc: "24 cores Arrow Lake com IA integrada para gaming.", preco: "R$ 3.999,00", rating: 4.7, icon: Cpu, cor: "#0071c5" },
  { nome: "Corsair 64GB DDR5 7200MHz", categoria: "Memória RAM", desc: "Latência mínima e overclock extremo para gaming.", preco: "R$ 2.499,00", rating: 4.7, icon: HardDrive, cor: "#ff8c00" },
  { nome: "Samsung 990 Pro 4TB", categoria: "SSD NVMe", desc: "7.450 MB/s de leitura para carregamentos instantâneos.", preco: "R$ 2.199,00", rating: 4.9, icon: HardDrive, cor: "#1428a0" },
  { nome: "Corsair RM1000x SHIFT", categoria: "Fonte", desc: "1000W 80+ Gold com conectores laterais.", preco: "R$ 1.299,00", rating: 4.8, icon: Zap, cor: "#ff8c00" },
  { nome: "ASUS ROG Maximus Z890", categoria: "Motherboard", desc: "DDR5, PCIe 5.0 e Wi-Fi 7 para a plataforma Intel mais nova.", preco: "R$ 3.499,00", rating: 4.6, icon: Cpu, cor: "#ed1c24" },
];

const plataformas = [
  { nome: "Steam", desc: "30.000+ jogos", detalhe: "Maior loja de PC", cor: "#1b2838" },
  { nome: "Epic Games", desc: "Free Games mensais", detalhe: "Exclusivos e freebies", cor: "#2d2d2d" },
  { nome: "GOG", desc: "DRM-Free", detalhe: "Clássicos e independentes", cor: "#b44a22" },
  { nome: "Xbox / Game Pass", desc: "100+ jogos", detalhe: "Assinatura premium", cor: "#107c10" },
];

const subcategorias = ["Placas de Vídeo", "Processadores", "Memória RAM", "SSD/HD", "Gabinetes", "Fontes", "Coolers", "Motherboards", "PCs Montados"];

export default function PCGaming() {
  const [hovered, setHovered] = useState<string | null>(null);
  const [activeSub, setActiveSub] = useState("Placas de Vídeo");

  return (
    <NexusLayout>
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "40px 20px" }}>
        <div style={{ marginBottom: "32px", display: "flex", alignItems: "center", gap: "12px" }}>
          <Monitor style={{ color: "#00ff88", width: 32, height: 32 }} />
          <div>
            <h2 style={{ fontSize: "32px", fontWeight: 800, color: "#fff", borderLeft: "4px solid #00ff88", paddingLeft: "14px" }}>
              PC Gaming
            </h2>
            <p style={{ color: "#666", fontSize: "13px", paddingLeft: "18px" }}>Hardware • Componentes • Plataformas • Benchmarks</p>
          </div>
        </div>

        {/* Plataformas */}
        <div style={{ marginBottom: "40px" }}>
          <h3 style={{ color: "#fff", fontSize: "20px", fontWeight: 700, borderLeft: "4px solid #00ff88", paddingLeft: "12px", marginBottom: "16px" }}>
            Plataformas de Jogos
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "12px" }}>
            {plataformas.map(plat => (
              <div key={plat.nome} style={{
                backgroundColor: plat.cor,
                border: "1px solid #232330",
                borderRadius: "10px",
                padding: "18px",
                cursor: "pointer",
                transition: "transform 0.2s, box-shadow 0.2s",
              }}
                onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 6px 20px rgba(0,255,136,0.2)"; }}
                onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "none"; }}
              >
                <div style={{ color: "#fff", fontWeight: 800, fontSize: "16px", marginBottom: "4px" }}>{plat.nome}</div>
                <div style={{ color: "#00ff88", fontSize: "13px", fontWeight: 600 }}>{plat.desc}</div>
                <div style={{ color: "#999", fontSize: "12px", marginTop: "4px" }}>{plat.detalhe}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Filtros */}
        <div style={{ marginBottom: "36px", display: "flex", flexWrap: "wrap", gap: "8px" }}>
          {subcategorias.map(sub => (
            <button key={sub} onClick={() => setActiveSub(sub)} style={{
              padding: "7px 16px",
              backgroundColor: activeSub === sub ? "#00ff88" : "#16161f",
              border: `1px solid ${activeSub === sub ? "#00ff88" : "#232330"}`,
              borderRadius: "20px",
              color: activeSub === sub ? "#000" : "#b3b3b3",
              fontSize: "13px",
              fontWeight: activeSub === sub ? 700 : 400,
              cursor: "pointer",
            }}>
              {sub}
            </button>
          ))}
        </div>

        {/* Hardware Grid */}
        <div>
          <h3 style={{ color: "#fff", fontSize: "22px", fontWeight: 700, borderLeft: "4px solid #00ff88", paddingLeft: "12px", marginBottom: "20px" }}>
            Hardware em Destaque
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "20px" }}>
            {componentes.map(comp => {
              const Icon = comp.icon;
              return (
                <div key={comp.nome}
                  style={{
                    backgroundColor: "#16161f",
                    border: `1px solid ${hovered === comp.nome ? "#00ff88" : "#232330"}`,
                    borderRadius: "10px",
                    overflow: "hidden",
                    transition: "transform 0.2s, box-shadow 0.2s, border-color 0.2s",
                    transform: hovered === comp.nome ? "translateY(-5px)" : "none",
                    boxShadow: hovered === comp.nome ? "0 8px 24px rgba(0,255,136,0.25)" : "none",
                  }}
                  onMouseEnter={() => setHovered(comp.nome)}
                  onMouseLeave={() => setHovered(null)}
                >
                  <div style={{
                    height: "130px",
                    background: `linear-gradient(135deg, ${comp.cor}33, ${comp.cor}11)`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}>
                    <Icon style={{ width: 64, height: 64, color: comp.cor }} />
                  </div>
                  <div style={{ padding: "16px" }}>
                    <div style={{ color: "#00ff88", fontSize: "10px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "1px", marginBottom: "6px" }}>{comp.categoria}</div>
                    <h3 style={{ color: "#fff", fontSize: "15px", fontWeight: 700, marginBottom: "6px" }}>{comp.nome}</h3>
                    <p style={{ color: "#999", fontSize: "12px", lineHeight: 1.5, marginBottom: "12px" }}>{comp.desc}</p>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "12px" }}>
                      <Star style={{ width: 13, height: 13, fill: "#fbbf24", color: "#fbbf24" }} />
                      <span style={{ color: "#fff", fontSize: "13px", fontWeight: 600 }}>{comp.rating}/5.0</span>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <span style={{ color: "#00ff88", fontSize: "16px", fontWeight: 800 }}>{comp.preco}</span>
                      <button style={{
                        display: "flex", alignItems: "center", gap: "6px",
                        backgroundColor: "#00ff88", color: "#000", border: "none",
                        padding: "8px 14px", borderRadius: "6px", fontSize: "12px", fontWeight: 700, cursor: "pointer",
                      }}>
                        <ShoppingCart style={{ width: 13, height: 13 }} />
                        Comprar
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </NexusLayout>
  );
}
