import { useState } from "react";
import { Keyboard, Star, ShoppingCart, Mouse, Headphones, MonitorSpeaker } from "lucide-react";
import { NexusLayout } from "../components/NexusLayout";

const perifericos = [
  { nome: "Logitech G Pro X Superlight 2", cat: "Mouse", desc: "25.600 DPI, 95g, sensor HERO 2 — o padrão do cenário pro.", preco: "R$ 999,00", rating: 4.9, icon: Mouse, cor: "#4a90d9" },
  { nome: "Razer BlackWidow V4 Pro", cat: "Teclado Mecânico", desc: "Switches Green com RGB Chroma e polling de 8000Hz.", preco: "R$ 1.299,00", rating: 4.8, icon: Keyboard, cor: "#00ff00" },
  { nome: "SteelSeries Arctis Nova Pro", cat: "Headset", desc: "Som Hi-Res, cancelamento de ruído e swappable battery.", preco: "R$ 1.799,00", rating: 4.9, icon: Headphones, cor: "#ff4500" },
  { nome: "LG UltraGear 27\" QD-OLED 360Hz", cat: "Monitor", desc: "QD-OLED 1ms com G-Sync Ultimate e resolução 2K.", preco: "R$ 5.499,00", rating: 4.9, icon: MonitorSpeaker, cor: "#b44aff" },
  { nome: "Corsair K70 Max Magnetic", cat: "Teclado Mecânico", desc: "Switches magnéticos com actuation point ajustável por tecla.", preco: "R$ 1.099,00", rating: 4.8, icon: Keyboard, cor: "#ff8c00" },
  { nome: "HyperX Cloud III Wireless", cat: "Headset", desc: "120h de bateria, DTS Spatial Audio e microfone destacável.", preco: "R$ 1.199,00", rating: 4.7, icon: Headphones, cor: "#cc0000" },
  { nome: "Zowie EC3-CW Wireless", cat: "Mouse", desc: "Wireless de baixíssima latência preferido dos pros de FPS.", preco: "R$ 799,00", rating: 4.8, icon: Mouse, cor: "#ff4500" },
  { nome: "Alienware AW3225QF", cat: "Monitor", desc: "32\" QD-OLED 4K 240Hz com DisplayPort 2.1.", preco: "R$ 8.999,00", rating: 5.0, icon: MonitorSpeaker, cor: "#0078d4" },
];

const softwares = [
  { nome: "iCUE", fab: "Corsair", desc: "Controle de RGB e macro" },
  { nome: "Synapse 4", fab: "Razer", desc: "Perfis e Chroma Studio" },
  { nome: "G HUB", fab: "Logitech", desc: "DPI, polling e lightsync" },
  { nome: "Armoury Crate", fab: "ASUS ROG", desc: "Aura Sync e AI features" },
];

const subcategorias = ["Mouses", "Teclados Mecânicos", "Headsets", "Monitores", "Mousepads", "Webcams", "Microfones", "Cadeiras Gamer", "RGB & Iluminação"];

export default function Perifericos() {
  const [hovered, setHovered] = useState<string | null>(null);
  const [activeSub, setActiveSub] = useState("Mouses");

  return (
    <NexusLayout>
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "40px 20px" }}>
        <div style={{ marginBottom: "32px", display: "flex", alignItems: "center", gap: "12px" }}>
          <Keyboard style={{ color: "#00ff88", width: 32, height: 32 }} />
          <div>
            <h2 style={{ fontSize: "32px", fontWeight: 800, color: "#fff", borderLeft: "4px solid #00ff88", paddingLeft: "14px" }}>
              Periféricos
            </h2>
            <p style={{ color: "#666", fontSize: "13px", paddingLeft: "18px" }}>Mouses • Teclados • Headsets • Monitores • Cadeiras</p>
          </div>
        </div>

        {/* Softwares */}
        <div style={{ marginBottom: "36px" }}>
          <h3 style={{ color: "#fff", fontSize: "20px", fontWeight: 700, borderLeft: "4px solid #00ff88", paddingLeft: "12px", marginBottom: "16px" }}>
            Softwares de Configuração
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "12px" }}>
            {softwares.map(sw => (
              <div key={sw.nome} style={{
                backgroundColor: "#16161f",
                border: "1px solid #232330",
                borderRadius: "10px",
                padding: "16px",
                textAlign: "center",
                cursor: "pointer",
                transition: "border-color 0.2s",
              }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = "#00ff88")}
                onMouseLeave={e => (e.currentTarget.style.borderColor = "#232330")}
              >
                <div style={{ color: "#00ff88", fontSize: "16px", fontWeight: 800, marginBottom: "4px" }}>{sw.nome}</div>
                <div style={{ color: "#b3b3b3", fontSize: "12px", marginBottom: "4px" }}>{sw.fab}</div>
                <div style={{ color: "#666", fontSize: "11px" }}>{sw.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Filtros */}
        <div style={{ marginBottom: "36px", display: "flex", flexWrap: "wrap", gap: "8px" }}>
          {subcategorias.map(sub => (
            <button key={sub} onClick={() => setActiveSub(sub)} style={{
              padding: "7px 16px",
              backgroundColor: activeSub === sub ? "#00ff88" : "#16161f",
              border: `1px solid ${activeSub === sub ? "#00ff88" : "#232330"}`,
              borderRadius: "20px",
              color: activeSub === sub ? "#000" : "#b3b3b3",
              fontSize: "13px",
              fontWeight: activeSub === sub ? 700 : 400,
              cursor: "pointer",
            }}>
              {sub}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div>
          <h3 style={{ color: "#fff", fontSize: "22px", fontWeight: 700, borderLeft: "4px solid #00ff88", paddingLeft: "12px", marginBottom: "20px" }}>
            Periféricos em Destaque
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "20px" }}>
            {perifericos.map(per => {
              const Icon = per.icon;
              return (
                <div key={per.nome}
                  style={{
                    backgroundColor: "#16161f",
                    border: `1px solid ${hovered === per.nome ? "#00ff88" : "#232330"}`,
                    borderRadius: "10px",
                    overflow: "hidden",
                    transition: "transform 0.2s, box-shadow 0.2s, border-color 0.2s",
                    transform: hovered === per.nome ? "translateY(-5px)" : "none",
                    boxShadow: hovered === per.nome ? "0 8px 24px rgba(0,255,136,0.25)" : "none",
                  }}
                  onMouseEnter={() => setHovered(per.nome)}
                  onMouseLeave={() => setHovered(null)}
                >
                  <div style={{
                    height: "130px",
                    background: `linear-gradient(135deg, ${per.cor}33, ${per.cor}11)`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}>
                    <Icon style={{ width: 64, height: 64, color: per.cor }} />
                  </div>
                  <div style={{ padding: "16px" }}>
                    <div style={{ color: "#00ff88", fontSize: "10px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "1px", marginBottom: "6px" }}>{per.cat}</div>
                    <h3 style={{ color: "#fff", fontSize: "14px", fontWeight: 700, marginBottom: "6px" }}>{per.nome}</h3>
                    <p style={{ color: "#999", fontSize: "12px", lineHeight: 1.5, marginBottom: "12px" }}>{per.desc}</p>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "12px" }}>
                      <Star style={{ width: 13, height: 13, fill: "#fbbf24", color: "#fbbf24" }} />
                      <span style={{ color: "#fff", fontSize: "13px", fontWeight: 600 }}>{per.rating}/5.0</span>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <span style={{ color: "#00ff88", fontSize: "16px", fontWeight: 800 }}>{per.preco}</span>
                      <button style={{
                        display: "flex", alignItems: "center", gap: "6px",
                        backgroundColor: "#00ff88", color: "#000", border: "none",
                        padding: "8px 14px", borderRadius: "6px", fontSize: "12px", fontWeight: 700, cursor: "pointer",
                      }}>
                        <ShoppingCart style={{ width: 13, height: 13 }} />
                        Comprar
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </NexusLayout>
  );
}
