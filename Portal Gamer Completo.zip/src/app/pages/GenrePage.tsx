import { useParams, Link } from "react-router";
import { ArrowLeft, Star } from "lucide-react";
import { NexusLayout } from "../components/NexusLayout";
import { gamesDatabase } from "../data/gameData";

export default function GenrePage() {
  const { genreKey } = useParams<{ genreKey: string }>();
  const data = genreKey ? gamesDatabase[genreKey] : null;

  if (!data) {
    return (
      <NexusLayout>
        <div style={{ maxWidth: "1200px", margin: "60px auto", padding: "0 20px", textAlign: "center" }}>
          <h2 style={{ color: "#fff", fontSize: "28px", marginBottom: "16px" }}>Gênero não encontrado</h2>
          <Link to="/home" style={{ color: "#00ff88", textDecoration: "none" }}>← Voltar para o Portal</Link>
        </div>
      </NexusLayout>
    );
  }

  return (
    <NexusLayout>
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "40px 20px" }}>
        <Link
          to="/home"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            backgroundColor: "#16161f",
            color: "#00ff88",
            border: "2px solid #00ff88",
            padding: "10px 20px",
            borderRadius: "6px",
            textDecoration: "none",
            fontSize: "14px",
            fontWeight: 700,
            marginBottom: "30px",
            transition: "background-color 0.2s, color 0.2s",
          }}
          onMouseEnter={e => { e.currentTarget.style.backgroundColor = "#00ff88"; e.currentTarget.style.color = "#000"; }}
          onMouseLeave={e => { e.currentTarget.style.backgroundColor = "#16161f"; e.currentTarget.style.color = "#00ff88"; }}
        >
          <ArrowLeft style={{ width: 16, height: 16 }} />
          Voltar para o Portal
        </Link>

        <div style={{ marginBottom: "30px" }}>
          <h2 style={{ fontSize: "32px", fontWeight: 800, color: "#fff", borderLeft: "4px solid #00ff88", paddingLeft: "14px", marginBottom: "8px" }}>
            {data.title}
          </h2>
          <p style={{ color: "#666", fontSize: "14px", paddingLeft: "18px" }}>{data.games.length} jogos nesta categoria</p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "24px" }}>
          {data.games.map(game => (
            <div key={game.id} style={{
              backgroundColor: "#16161f",
              borderRadius: "8px",
              overflow: "hidden",
              border: "1px solid #232330",
              display: "flex",
              flexDirection: "column",
              transition: "transform 0.2s, box-shadow 0.2s",
            }}
              onMouseEnter={e => {
                e.currentTarget.style.transform = "translateY(-5px)";
                e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,255,136,0.25)";
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.boxShadow = "none";
              }}
            >
              <div style={{
                height: "180px",
                background: data.color,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "15px",
                fontWeight: 700,
                color: "#fff",
                padding: "20px",
                textAlign: "center",
              }}>
                [ {game.name} ]
              </div>
              <div style={{ padding: "18px", flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
                  <span style={{ backgroundColor: "#00ff88", color: "#000", fontSize: "10px", fontWeight: 700, padding: "3px 8px", borderRadius: "4px" }}>{game.tag}</span>
                  {game.score && (
                    <span style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "4px",
                      backgroundColor: game.score >= 90 ? "#00ff88" : game.score >= 75 ? "#fbbf24" : "#f87171",
                      color: "#000",
                      fontSize: "11px",
                      fontWeight: 800,
                      padding: "2px 8px",
                      borderRadius: "4px",
                    }}>
                      <Star style={{ width: 10, height: 10 }} />
                      {game.score}/100
                    </span>
                  )}
                </div>
                <h3 style={{ color: "#fff", fontSize: "16px", fontWeight: 700, marginBottom: "8px" }}>{game.name}</h3>
                <p style={{ color: "#b3b3b3", fontSize: "13px", lineHeight: 1.6, marginBottom: "12px" }}>{game.desc}</p>
                {game.price && (
                  <div style={{ color: "#00ff88", fontSize: "14px", fontWeight: 700 }}>{game.price}</div>
                )}
              </div>
              {game.isNew && (
                <div style={{ backgroundColor: "#00ff88", color: "#000", textAlign: "center", padding: "8px", fontSize: "12px", fontWeight: 800 }}>
                  🔥 LANÇAMENTO RECENTE
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Link para todos os jogos */}
        <div style={{ textAlign: "center", marginTop: "40px" }}>
          <Link to="/jogos" style={{
            backgroundColor: "#16161f",
            color: "#00ff88",
            border: "2px solid #00ff88",
            padding: "12px 32px",
            borderRadius: "6px",
            textDecoration: "none",
            fontSize: "14px",
            fontWeight: 700,
          }}>
            Ver Biblioteca Completa de Jogos
          </Link>
        </div>
      </div>
    </NexusLayout>
  );
}
