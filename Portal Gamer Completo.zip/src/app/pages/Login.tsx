import { Link, useNavigate } from "react-router";
import { Gamepad2, Mail, Lock } from "lucide-react";
import { useState } from "react";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/home");
  };

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#0f0f13", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
      <div style={{ width: "100%", maxWidth: "420px" }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: "36px" }}>
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
            <Gamepad2 style={{ color: "#00ff88", width: 40, height: 40 }} />
            <span style={{ fontSize: "28px", fontWeight: 900, letterSpacing: "2px", color: "#fff", textTransform: "uppercase" }}>
              Nexus<span style={{ color: "#00ff88" }}>Gaming</span>
            </span>
          </div>
          <p style={{ color: "#666", fontSize: "14px" }}>O Portal Definitivo do Universo Gamer</p>
        </div>

        {/* Card */}
        <div style={{ backgroundColor: "#16161f", border: "1px solid #232330", borderRadius: "12px", padding: "36px" }}>
          <h2 style={{ color: "#fff", fontSize: "22px", fontWeight: 700, marginBottom: "24px" }}>Entrar na Conta</h2>

          <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div>
              <label style={{ color: "#b3b3b3", fontSize: "13px", display: "block", marginBottom: "6px" }}>Email</label>
              <div style={{ position: "relative" }}>
                <Mail style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "#666", width: 16, height: 16 }} />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  required
                  style={{
                    width: "100%",
                    padding: "11px 12px 11px 38px",
                    backgroundColor: "#0f0f13",
                    border: "1px solid #232330",
                    borderRadius: "8px",
                    color: "#fff",
                    fontSize: "14px",
                    outline: "none",
                    boxSizing: "border-box",
                  }}
                  onFocus={e => (e.target.style.borderColor = "#00ff88")}
                  onBlur={e => (e.target.style.borderColor = "#232330")}
                />
              </div>
            </div>

            <div>
              <label style={{ color: "#b3b3b3", fontSize: "13px", display: "block", marginBottom: "6px" }}>Senha</label>
              <div style={{ position: "relative" }}>
                <Lock style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "#666", width: 16, height: 16 }} />
                <input
                  type="password"
                  value={senha}
                  onChange={e => setSenha(e.target.value)}
                  placeholder="••••••••"
                  required
                  style={{
                    width: "100%",
                    padding: "11px 12px 11px 38px",
                    backgroundColor: "#0f0f13",
                    border: "1px solid #232330",
                    borderRadius: "8px",
                    color: "#fff",
                    fontSize: "14px",
                    outline: "none",
                    boxSizing: "border-box",
                  }}
                  onFocus={e => (e.target.style.borderColor = "#00ff88")}
                  onBlur={e => (e.target.style.borderColor = "#232330")}
                />
              </div>
            </div>

            <button
              type="submit"
              style={{
                width: "100%",
                backgroundColor: "#00ff88",
                color: "#000",
                border: "none",
                padding: "13px",
                borderRadius: "8px",
                fontSize: "15px",
                fontWeight: 800,
                cursor: "pointer",
                letterSpacing: "0.5px",
                marginTop: "6px",
                transition: "opacity 0.2s",
              }}
              onMouseEnter={e => (e.currentTarget.style.opacity = "0.9")}
              onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
            >
              Entrar no Portal
            </button>
          </form>

          <div style={{ marginTop: "20px", textAlign: "center", color: "#666", fontSize: "14px" }}>
            Não tem uma conta?{" "}
            <Link to="/cadastro" style={{ color: "#00ff88", textDecoration: "none", fontWeight: 700 }}>
              Cadastre-se grátis
            </Link>
          </div>
        </div>

        <p style={{ textAlign: "center", color: "#333", fontSize: "12px", marginTop: "20px" }}>
          NexusGaming © 2026 — Todos os direitos reservados
        </p>
      </div>
    </div>
  );
}
