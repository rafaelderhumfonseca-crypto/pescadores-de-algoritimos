import { Link, useNavigate } from "react-router";
import { Gamepad2, Mail, Lock, User } from "lucide-react";
import { useState } from "react";

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "11px 12px 11px 38px",
  backgroundColor: "#0f0f13",
  border: "1px solid #232330",
  borderRadius: "8px",
  color: "#fff",
  fontSize: "14px",
  outline: "none",
  boxSizing: "border-box",
};

export default function Cadastro() {
  const navigate = useNavigate();
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");

  const handleCadastro = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/home");
  };

  const focusBorder = (e: React.FocusEvent<HTMLInputElement>) => (e.target.style.borderColor = "#00ff88");
  const blurBorder = (e: React.FocusEvent<HTMLInputElement>) => (e.target.style.borderColor = "#232330");

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#0f0f13", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
      <div style={{ width: "100%", maxWidth: "420px" }}>
        <div style={{ textAlign: "center", marginBottom: "36px" }}>
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
            <Gamepad2 style={{ color: "#00ff88", width: 40, height: 40 }} />
            <span style={{ fontSize: "28px", fontWeight: 900, letterSpacing: "2px", color: "#fff", textTransform: "uppercase" }}>
              Nexus<span style={{ color: "#00ff88" }}>Gaming</span>
            </span>
          </div>
          <p style={{ color: "#666", fontSize: "14px" }}>Junte-se à maior comunidade gamer do Brasil</p>
        </div>

        <div style={{ backgroundColor: "#16161f", border: "1px solid #232330", borderRadius: "12px", padding: "36px" }}>
          <h2 style={{ color: "#fff", fontSize: "22px", fontWeight: 700, marginBottom: "24px" }}>Criar Conta Grátis</h2>

          <form onSubmit={handleCadastro} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            {[
              { label: "Nome de usuário", value: nome, setter: setNome, type: "text", placeholder: "SeuNickGamer", Icon: User },
              { label: "Email", value: email, setter: setEmail, type: "email", placeholder: "seu@email.com", Icon: Mail },
              { label: "Senha", value: senha, setter: setSenha, type: "password", placeholder: "••••••••", Icon: Lock },
              { label: "Confirmar Senha", value: confirmarSenha, setter: setConfirmarSenha, type: "password", placeholder: "••••••••", Icon: Lock },
            ].map(field => (
              <div key={field.label}>
                <label style={{ color: "#b3b3b3", fontSize: "13px", display: "block", marginBottom: "6px" }}>{field.label}</label>
                <div style={{ position: "relative" }}>
                  <field.Icon style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "#666", width: 16, height: 16 }} />
                  <input
                    type={field.type}
                    value={field.value}
                    onChange={e => field.setter(e.target.value)}
                    placeholder={field.placeholder}
                    required
                    style={inputStyle}
                    onFocus={focusBorder}
                    onBlur={blurBorder}
                  />
                </div>
              </div>
            ))}

            <button
              type="submit"
              style={{
                width: "100%",
                backgroundColor: "#00ff88",
                color: "#000",
                border: "none",
                padding: "13px",
                borderRadius: "8px",
                fontSize: "15px",
                fontWeight: 800,
                cursor: "pointer",
                letterSpacing: "0.5px",
                marginTop: "6px",
              }}
              onMouseEnter={e => (e.currentTarget.style.opacity = "0.9")}
              onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
            >
              Criar Conta e Entrar
            </button>
          </form>

          <div style={{ marginTop: "20px", textAlign: "center", color: "#666", fontSize: "14px" }}>
            Já tem uma conta?{" "}
            <Link to="/" style={{ color: "#00ff88", textDecoration: "none", fontWeight: 700 }}>
              Fazer login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
