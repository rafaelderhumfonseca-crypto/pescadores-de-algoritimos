import { useState } from "react";
import { Link } from "react-router";
import { TrendingUp, Star, Trophy, ChevronRight, MessageSquare, Clock, Flame, Gamepad2, Monitor, Keyboard, Cpu } from "lucide-react";
import { NexusLayout } from "../components/NexusLayout";
import { lancamentosData, analisesData, topVendasData, hardwareData, forumPosts, gamesDatabase } from "../data/gameData";

const genreCategories = [
  { key: "rpg", label: "RPG de Ação", color: "linear-gradient(135deg, #401b1b, #210a0a)", emoji: "⚔️" },
  { key: "fps", label: "FPS / Tiro", color: "linear-gradient(135deg, #1b2640, #0a101f)", emoji: "🎯" },
  { key: "esports", label: "E-Sports", color: "linear-gradient(135deg, #3c1b40, #1d0920)", emoji: "🏆" },
  { key: "terror", label: "Terror", color: "linear-gradient(135deg, #181818, #050505)", emoji: "👻" },
  { key: "estrategia", label: "Estratégia", color: "linear-gradient(135deg, #1b2640, #0a101f)", emoji: "♟️" },
  { key: "retro", label: "Retro / Clássicos", color: "linear-gradient(135deg, #40371b, #1f1a0a)", emoji: "🕹️" },
  { key: "indie", label: "Indie", color: "linear-gradient(135deg, #1b402e, #091c12)", emoji: "🌱" },
  { key: "aventura", label: "Aventura / Open World", color: "linear-gradient(135deg, #1a3a2a, #0a1a12)", emoji: "🗺️" },
];

const mainCategories = [
  { label: "Consoles", desc: "PlayStation, Xbox, Nintendo", to: "/consoles", icon: Gamepad2, color: "#7c3aed" },
  { label: "PC Gaming", desc: "Placas de vídeo, CPUs, Steam", to: "/pc-gaming", icon: Monitor, color: "#2563eb" },
  { label: "Periféricos", desc: "Mouses, teclados, headsets", to: "/perifericos", icon: Keyboard, color: "#16a34a" },
  { label: "Componentes", desc: "Hardware, benchmarks, guias", to: "/pc-gaming", icon: Cpu, color: "#ea580c" },
];

const cardStyle: React.CSSProperties = {
  backgroundColor: "#16161f",
  borderRadius: "8px",
  overflow: "hidden",
  border: "1px solid #232330",
  display: "flex",
  flexDirection: "column",
  transition: "transform 0.2s, box-shadow 0.2s",
  cursor: "pointer",
};

function ScoreBadge({ score }: { score: number }) {
  const color = score >= 90 ? "#00ff88" : score >= 75 ? "#fbbf24" : "#f87171";
  return (
    <span style={{
      backgroundColor: color,
      color: "#000",
      fontSize: "11px",
      fontWeight: 800,
      padding: "2px 7px",
      borderRadius: "4px",
      display: "inline-block",
    }}>
      {score}/100
    </span>
  );
}

function SectionHeader({ title, link, linkLabel = "Ver todos" }: { title: string; link?: string; linkLabel?: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "20px" }}>
      <h2 style={{ fontSize: "24px", fontWeight: 700, borderLeft: "4px solid #00ff88", paddingLeft: "12px", color: "#fff" }}>
        {title}
      </h2>
      {link && (
        <Link to={link} style={{ color: "#00ff88", fontSize: "13px", textDecoration: "none", display: "flex", alignItems: "center", gap: "4px" }}>
          {linkLabel} <ChevronRight style={{ width: 14, height: 14 }} />
        </Link>
      )}
    </div>
  );
}

export default function Home() {
  const [hovered, setHovered] = useState<string | null>(null);

  return (
    <NexusLayout>
      {/* Hero */}
      <div style={{
        background: "linear-gradient(rgba(0,0,0,0.75), #0f0f13), url('https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=1920') no-repeat center/cover",
        minHeight: "340px",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        padding: "40px 20px",
      }}>
        <h1 style={{ fontSize: "clamp(28px, 5vw, 52px)", fontWeight: 900, marginBottom: "12px", letterSpacing: "-1px" }}>
          O Universo Gamer em <span style={{ color: "#00ff88" }}>um só lugar</span>
        </h1>
        <p style={{ color: "#b3b3b3", fontSize: "clamp(14px, 2vw, 18px)", maxWidth: "600px" }}>
          Encontre desde a placa de vídeo mais potente até o indie mais aclamado do ano. Hardware, Software, Análises e Comunidade.
        </p>
        <div style={{ display: "flex", gap: "12px", marginTop: "24px", flexWrap: "wrap", justifyContent: "center" }}>
          <Link to="/jogos" style={{
            backgroundColor: "#00ff88", color: "#000", padding: "11px 28px", borderRadius: "6px",
            fontWeight: 700, textDecoration: "none", fontSize: "14px", letterSpacing: "0.5px",
          }}>
            Explorar Jogos
          </Link>
          <Link to="/pc-gaming" style={{
            border: "2px solid #00ff88", color: "#00ff88", padding: "11px 28px", borderRadius: "6px",
            fontWeight: 700, textDecoration: "none", fontSize: "14px",
          }}>
            Ver Hardware
          </Link>
        </div>
      </div>

      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "40px 20px" }}>

        {/* Quick Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "16px", marginBottom: "60px" }}>
          {[
            { icon: <Flame style={{ color: "#00ff88", width: 24, height: 24 }} />, label: "Lançamentos da Semana", value: `${lancamentosData.length} novos títulos`, to: "#lancamentos" },
            { icon: <Star style={{ color: "#fbbf24", width: 24, height: 24 }} />, label: "Análises em Destaque", value: `${analisesData.length} reviews recentes`, to: "#analises" },
            { icon: <Trophy style={{ color: "#f97316", width: 24, height: 24 }} />, label: "Top Vendas", value: `${topVendasData.length} mais vendidos`, to: "#topvendas" },
            { icon: <TrendingUp style={{ color: "#7c3aed", width: 24, height: 24 }} />, label: "Fórum Ativo", value: `${forumPosts.length} discussões quentes`, to: "#forum" },
          ].map(stat => (
            <a key={stat.label} href={stat.to} style={{ textDecoration: "none" }}>
              <div style={{ backgroundColor: "#16161f", border: "1px solid #232330", borderRadius: "10px", padding: "20px", display: "flex", gap: "16px", alignItems: "center", transition: "border-color 0.2s" }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = "#00ff88")}
                onMouseLeave={e => (e.currentTarget.style.borderColor = "#232330")}>
                <div style={{ backgroundColor: "#0f0f13", padding: "12px", borderRadius: "8px" }}>{stat.icon}</div>
                <div>
                  <div style={{ color: "#fff", fontWeight: 600, fontSize: "15px" }}>{stat.label}</div>
                  <div style={{ color: "#666", fontSize: "13px", marginTop: "2px" }}>{stat.value}</div>
                </div>
              </div>
            </a>
          ))}
        </div>

        {/* Categorias Principais */}
        <section style={{ marginBottom: "60px" }}>
          <SectionHeader title="Categorias Principais" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px" }}>
            {mainCategories.map(cat => (
              <Link key={cat.label} to={cat.to} style={{ textDecoration: "none" }}>
                <div style={{
                  backgroundColor: "#16161f",
                  border: `1px solid ${hovered === cat.label ? cat.color : "#232330"}`,
                  borderRadius: "10px",
                  padding: "24px 20px",
                  textAlign: "center",
                  transition: "transform 0.2s, box-shadow 0.2s, border-color 0.2s",
                  transform: hovered === cat.label ? "translateY(-4px)" : "none",
                  boxShadow: hovered === cat.label ? `0 8px 24px ${cat.color}40` : "none",
                }}
                  onMouseEnter={() => setHovered(cat.label)}
                  onMouseLeave={() => setHovered(null)}
                >
                  <cat.icon style={{ color: cat.color, width: 36, height: 36, margin: "0 auto 12px" }} />
                  <div style={{ color: "#fff", fontWeight: 700, fontSize: "16px", marginBottom: "4px" }}>{cat.label}</div>
                  <div style={{ color: "#666", fontSize: "12px" }}>{cat.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Lançamentos da Semana */}
        <section id="lancamentos" style={{ marginBottom: "60px" }}>
          <SectionHeader title="🔥 Lançamentos da Semana" link="/jogos" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "20px" }}>
            {lancamentosData.map(game => (
              <Link key={game.id} to={`/genero/${game.genre}`} style={{ textDecoration: "none" }}>
                <div
                  style={{ ...cardStyle, transform: hovered === game.id ? "translateY(-5px)" : "none", boxShadow: hovered === game.id ? "0 8px 20px rgba(0,255,136,0.25)" : "none" }}
                  onMouseEnter={() => setHovered(game.id)}
                  onMouseLeave={() => setHovered(null)}
                >
                  <div style={{
                    height: "140px",
                    background: gamesDatabase[game.genre]?.color || "linear-gradient(135deg, #232330, #16161f)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "14px",
                    color: "#fff",
                    fontWeight: 700,
                    position: "relative",
                  }}>
                    <span style={{ padding: "20px", textAlign: "center" }}>[ {game.name} ]</span>
                    <span style={{
                      position: "absolute",
                      top: "10px",
                      right: "10px",
                      backgroundColor: "#00ff88",
                      color: "#000",
                      fontSize: "10px",
                      fontWeight: 800,
                      padding: "3px 8px",
                      borderRadius: "4px",
                    }}>NOVO</span>
                  </div>
                  <div style={{ padding: "16px", flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
                      <span style={{ backgroundColor: "#00ff88", color: "#000", fontSize: "10px", fontWeight: 700, padding: "2px 7px", borderRadius: "4px" }}>{game.tag}</span>
                      {game.score && <ScoreBadge score={game.score} />}
                    </div>
                    <h3 style={{ color: "#fff", fontSize: "15px", fontWeight: 700, marginBottom: "8px" }}>{game.name}</h3>
                    <p style={{ color: "#999", fontSize: "13px", lineHeight: 1.5, marginBottom: "10px" }}>{game.desc}</p>
                    {game.price && <div style={{ color: "#00ff88", fontSize: "13px", fontWeight: 600 }}>{game.price}</div>}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Análises em Destaque + Top Vendas em grid 2 colunas */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "40px", marginBottom: "60px" }}>

          {/* Análises em Destaque */}
          <section id="analises">
            <SectionHeader title="⭐ Análises em Destaque" />
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              {analisesData.map(analise => (
                <div key={analise.id} style={{
                  backgroundColor: "#16161f",
                  border: "1px solid #232330",
                  borderRadius: "8px",
                  padding: "16px",
                  transition: "border-color 0.2s",
                }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = "#00ff88")}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = "#232330")}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "6px" }}>
                    <span style={{ backgroundColor: "#00ff88", color: "#000", fontSize: "10px", fontWeight: 700, padding: "2px 7px", borderRadius: "4px" }}>{analise.tag}</span>
                    <ScoreBadge score={analise.score} />
                  </div>
                  <div style={{ color: "#fff", fontWeight: 700, fontSize: "14px", marginBottom: "4px" }}>{analise.game}</div>
                  <div style={{ color: "#b3b3b3", fontSize: "12px", fontStyle: "italic", marginBottom: "6px" }}>"{analise.resumo}"</div>
                  <div style={{ color: "#666", fontSize: "11px", display: "flex", gap: "12px" }}>
                    <span>por {analise.reviewer}</span>
                    <span>{analise.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Top Vendas */}
          <section id="topvendas">
            <SectionHeader title="📊 Top Vendas" />
            <div style={{ backgroundColor: "#16161f", border: "1px solid #232330", borderRadius: "8px", overflow: "hidden" }}>
              {topVendasData.map((game, i) => (
                <Link key={game.id} to={`/genero/${game.genre}`} style={{ textDecoration: "none" }}>
                  <div style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "12px",
                    padding: "12px 16px",
                    borderBottom: i < topVendasData.length - 1 ? "1px solid #232330" : "none",
                    transition: "background-color 0.2s",
                  }}
                    onMouseEnter={e => (e.currentTarget.style.backgroundColor = "#1e1e2a")}
                    onMouseLeave={e => (e.currentTarget.style.backgroundColor = "transparent")}
                  >
                    <div style={{
                      width: "28px",
                      height: "28px",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "12px",
                      fontWeight: 800,
                      backgroundColor: i < 3 ? "#00ff88" : "#232330",
                      color: i < 3 ? "#000" : "#666",
                      flexShrink: 0,
                    }}>
                      {game.rank}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: "#fff", fontSize: "13px", fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{game.name}</div>
                      <div style={{ color: "#666", fontSize: "11px" }}>{game.tag}</div>
                    </div>
                    <div style={{ color: "#00ff88", fontSize: "12px", fontWeight: 600, whiteSpace: "nowrap" }}>{game.price}</div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        </div>

        {/* Hardware & Equipamentos */}
        <section id="hardware" style={{ marginBottom: "60px" }}>
          <SectionHeader title="🖥️ Hardware & Equipamentos" link="/pc-gaming" linkLabel="Ver PC Gaming" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "20px" }}>
            {hardwareData.map(item => (
              <Link key={item.id} to="/pc-gaming" style={{ textDecoration: "none" }}>
                <div
                  style={{ ...cardStyle, transform: hovered === item.id ? "translateY(-5px)" : "none", boxShadow: hovered === item.id ? "0 8px 20px rgba(0,255,136,0.2)" : "none" }}
                  onMouseEnter={() => setHovered(item.id)}
                  onMouseLeave={() => setHovered(null)}
                >
                  <div style={{
                    height: "120px",
                    background: "linear-gradient(135deg, #1b2640, #0a101f)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#fff",
                    fontWeight: 700,
                    fontSize: "13px",
                    padding: "16px",
                    textAlign: "center",
                  }}>
                    [ {item.name} ]
                  </div>
                  <div style={{ padding: "16px" }}>
                    <span style={{ backgroundColor: "#00ff88", color: "#000", fontSize: "10px", fontWeight: 700, padding: "2px 7px", borderRadius: "4px", display: "inline-block", marginBottom: "8px" }}>{item.tag}</span>
                    <h3 style={{ color: "#fff", fontSize: "14px", fontWeight: 700, marginBottom: "6px" }}>{item.name}</h3>
                    <p style={{ color: "#999", fontSize: "12px", lineHeight: 1.5, marginBottom: "8px" }}>{item.desc}</p>
                    {item.price && <div style={{ color: "#00ff88", fontSize: "12px", fontWeight: 600 }}>{item.price}</div>}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Software / Gêneros de Jogos */}
        <section id="generos" style={{ marginBottom: "60px" }}>
          <SectionHeader title="🎮 Explorar por Gênero" link="/jogos" linkLabel="Biblioteca completa" />
          <p style={{ color: "#666", fontSize: "13px", marginBottom: "20px", marginTop: "-12px" }}>Clique em uma categoria para explorar os jogos desse estilo.</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: "16px" }}>
            {genreCategories.map(genre => (
              <Link key={genre.key} to={`/genero/${genre.key}`} style={{ textDecoration: "none" }}>
                <div
                  style={{
                    ...cardStyle,
                    transform: hovered === genre.key ? "translateY(-5px)" : "none",
                    boxShadow: hovered === genre.key ? "0 8px 24px rgba(0,255,136,0.25)" : "none",
                  }}
                  onMouseEnter={() => setHovered(genre.key)}
                  onMouseLeave={() => setHovered(null)}
                >
                  <div style={{
                    height: "110px",
                    background: genre.color,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "40px",
                  }}>
                    {genre.emoji}
                  </div>
                  <div style={{ padding: "14px" }}>
                    <h3 style={{ color: "#fff", fontSize: "14px", fontWeight: 700, marginBottom: "4px" }}>{genre.label}</h3>
                    <p style={{ color: "#666", fontSize: "12px" }}>
                      {gamesDatabase[genre.key]?.games.length || 0} jogos na biblioteca
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Comunidade & Fórum */}
        <section id="forum" style={{ marginBottom: "40px" }}>
          <SectionHeader title="💬 Comunidade & Fórum" />
          <div style={{ backgroundColor: "#16161f", border: "1px solid #232330", borderRadius: "8px", overflow: "hidden" }}>
            {forumPosts.map((post, i) => (
              <div
                key={post.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "16px 20px",
                  borderBottom: i < forumPosts.length - 1 ? "1px solid #232330" : "none",
                  cursor: "pointer",
                  transition: "background-color 0.2s",
                }}
                onMouseEnter={e => (e.currentTarget.style.backgroundColor = "#1e1e2a")}
                onMouseLeave={e => (e.currentTarget.style.backgroundColor = "transparent")}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                    <span style={{ backgroundColor: "#232330", color: "#00ff88", fontSize: "10px", fontWeight: 700, padding: "2px 7px", borderRadius: "4px" }}>{post.category}</span>
                    <h4 style={{ color: "#fff", fontSize: "14px", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{post.title}</h4>
                  </div>
                  <div style={{ display: "flex", gap: "12px", color: "#666", fontSize: "11px" }}>
                    <span style={{ display: "flex", alignItems: "center", gap: "4px" }}><Clock style={{ width: 10, height: 10 }} />{post.time}</span>
                    <span>por {post.author}</span>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: "6px", color: "#00ff88", fontSize: "13px", fontWeight: 600, marginLeft: "16px", whiteSpace: "nowrap" }}>
                  <MessageSquare style={{ width: 14, height: 14 }} />
                  {post.replies}
                </div>
              </div>
            ))}
          </div>
        </section>

      </div>
    </NexusLayout>
  );
}
