import { useState } from "react";
import { Link } from "react-router";
import { NexusLayout } from "../components/NexusLayout";
import { gamesDatabase } from "../data/gameData";

const genreCategories = [
  { key: "rpg", label: "RPG de Ação", emoji: "⚔️", desc: "Action RPG, JRPG, Open World" },
  { key: "fps", label: "FPS / Tiro", emoji: "🎯", desc: "First Person, Third Person, Battle Royale" },
  { key: "esports", label: "E-Sports / Competitivo", emoji: "🏆", desc: "MOBA, Tático, Luta" },
  { key: "terror", label: "Terror / Horror", emoji: "👻", desc: "Survival Horror, Terror Psicológico" },
  { key: "estrategia", label: "Estratégia", emoji: "♟️", desc: "RTS, Turn-Based, Tycoon, 4X" },
  { key: "retro", label: "Retro / Clássicos", emoji: "🕹️", desc: "Emulação, Remakes, Clássicos atemporais" },
  { key: "indie", label: "Indie", emoji: "🌱", desc: "Metroidvania, Roguelike, Pixel Art" },
  { key: "aventura", label: "Aventura / Open World", emoji: "🗺️", desc: "Mundo Aberto, Plataformer, Exploração" },
];

const categorias = ["Lançamentos 2026", "Mais Vendidos", "Free to Play", "Multiplayer", "Single Player", "VR Games", "Early Access", "Game Pass"];

export default function Jogos() {
  const [hovered, setHovered] = useState<string | null>(null);
  const totalGames = Object.values(gamesDatabase).reduce((acc, db) => acc + db.games.length, 0);

  return (
    <NexusLayout>
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "40px 20px" }}>
        <div style={{ marginBottom: "32px" }}>
          <h2 style={{ fontSize: "32px", fontWeight: 800, color: "#fff", borderLeft: "4px solid #00ff88", paddingLeft: "14px", marginBottom: "8px" }}>
            Biblioteca de Jogos
          </h2>
          <p style={{ color: "#666", fontSize: "14px", paddingLeft: "18px" }}>
            Explore {totalGames}+ jogos organizados por gênero, plataforma e categoria
          </p>
        </div>

        {/* Filtros rápidos */}
        <div style={{ marginBottom: "40px" }}>
          <div style={{ color: "#b3b3b3", fontSize: "13px", marginBottom: "10px" }}>Categorias Especiais</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
            {categorias.map(cat => (
              <button key={cat} style={{
                padding: "7px 16px",
                backgroundColor: "#16161f",
                border: "1px solid #232330",
                borderRadius: "20px",
                color: "#b3b3b3",
                fontSize: "13px",
                cursor: "pointer",
                transition: "all 0.2s",
              }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#00ff88"; e.currentTarget.style.color = "#00ff88"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#232330"; e.currentTarget.style.color = "#b3b3b3"; }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Grid de Gêneros */}
        <div style={{ marginBottom: "20px", color: "#b3b3b3", fontSize: "13px" }}>Explorar por Gênero — clique para ver os jogos</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "20px" }}>
          {genreCategories.map(genre => {
            const db = gamesDatabase[genre.key];
            const topGame = db?.games[0];
            return (
              <Link key={genre.key} to={`/genero/${genre.key}`} style={{ textDecoration: "none" }}>
                <div
                  style={{
                    backgroundColor: "#16161f",
                    border: `1px solid ${hovered === genre.key ? "#00ff88" : "#232330"}`,
                    borderRadius: "10px",
                    overflow: "hidden",
                    transition: "transform 0.2s, box-shadow 0.2s, border-color 0.2s",
                    transform: hovered === genre.key ? "translateY(-5px)" : "none",
                    boxShadow: hovered === genre.key ? "0 8px 24px rgba(0,255,136,0.25)" : "none",
                  }}
                  onMouseEnter={() => setHovered(genre.key)}
                  onMouseLeave={() => setHovered(null)}
                >
                  <div style={{
                    height: "110px",
                    background: db?.color || "#232330",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "44px",
                  }}>
                    {genre.emoji}
                  </div>
                  <div style={{ padding: "18px" }}>
                    <h3 style={{ color: "#fff", fontSize: "16px", fontWeight: 700, marginBottom: "4px" }}>{genre.label}</h3>
                    <p style={{ color: "#666", fontSize: "12px", marginBottom: "12px" }}>{genre.desc}</p>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <span style={{ color: "#00ff88", fontSize: "13px", fontWeight: 600 }}>{db?.games.length || 0} jogos</span>
                      {topGame?.score && (
                        <span style={{ backgroundColor: "#00ff88", color: "#000", fontSize: "10px", fontWeight: 800, padding: "2px 7px", borderRadius: "4px" }}>
                          Top {topGame.score}/100
                        </span>
                      )}
                    </div>
                    {topGame && (
                      <div style={{ marginTop: "10px", padding: "8px", backgroundColor: "#0f0f13", borderRadius: "6px" }}>
                        <div style={{ color: "#666", fontSize: "10px", marginBottom: "2px" }}>EM DESTAQUE</div>
                        <div style={{ color: "#fff", fontSize: "12px", fontWeight: 600 }}>{topGame.name}</div>
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </NexusLayout>
  );
}
