export interface Game {
  id: string;
  name: string;
  desc: string;
  tag: string;
  genre: string;
  platform?: string;
  score?: number;
  price?: string;
  rank?: number;
  isNew?: boolean;
}

export interface HardwareItem {
  id: string;
  name: string;
  desc: string;
  tag: string;
  category: string;
  price?: string;
}

export interface ForumPost {
  id: string;
  title: string;
  author: string;
  category: string;
  time: string;
  replies: number;
}

export const gamesDatabase: Record<string, { title: string; color: string; games: Game[] }> = {
  rpg: {
    title: "RPGs de Ação e Aventura",
    color: "linear-gradient(135deg, #401b1b, #210a0a)",
    games: [
      { id: "rpg-1", name: "Elden Ring: Shadow of the Erdtree", desc: "A aclamada e desafiadora expansão das Terras Intermédias.", tag: "GotY", genre: "rpg", score: 96, price: "R$ 159,90" },
      { id: "rpg-2", name: "The Witcher 4: Polaris", desc: "O início da nova saga épica de caça aos monstros da CD Projekt Red.", tag: "Novo", genre: "rpg", score: 94, price: "R$ 299,90", isNew: true },
      { id: "rpg-3", name: "Cyberpunk 2077: Ultimate Edition", desc: "Explore Night City em sua versão definitiva com Overdrive Ray Tracing.", tag: "Clássico Moderno", genre: "rpg", score: 92, price: "R$ 199,90" },
      { id: "rpg-4", name: "Final Fantasy XVI", desc: "O retorno às raízes da fantasia com combate tático em tempo real.", tag: "Exclusivo", genre: "rpg", score: 89, price: "R$ 249,90" },
      { id: "rpg-5", name: "Dragon's Dogma 2", desc: "Uma obra-prima de design de mundo aberto com combate visceral.", tag: "Aventura", genre: "rpg", score: 91, price: "R$ 219,90" },
      { id: "rpg-6", name: "Baldur's Gate 3", desc: "O melhor RPG de turnos já criado, com liberdade narrativa sem precedentes.", tag: "GotY", genre: "rpg", score: 97, price: "R$ 239,90" },
    ]
  },
  fps: {
    title: "FPS e Jogos de Tiro",
    color: "linear-gradient(135deg, #1b2640, #0a101f)",
    games: [
      { id: "fps-1", name: "Call of Duty: Black Ops 7", desc: "A nova campanha cinematográfica e multijogador renovado para 2026.", tag: "Novo", genre: "fps", score: 85, price: "R$ 299,90", isNew: true },
      { id: "fps-2", name: "Doom: The Dark Ages", desc: "Retorno brutal do Doom Slayer ao estilo de combate mais visceral.", tag: "Lançamento", genre: "fps", score: 93, price: "R$ 249,90", isNew: true },
      { id: "fps-3", name: "Battlefield 2042", desc: "Combates em larga escala com veículos e destruição do ambiente.", tag: "Multiplayer", genre: "fps", score: 79, price: "R$ 99,90" },
      { id: "fps-4", name: "Halo Infinite", desc: "O Master Chief retorna em uma saga aberta com multijogador grátis.", tag: "Xbox", genre: "fps", score: 87, price: "R$ 149,90" },
      { id: "fps-5", name: "Metro Exodus: Enhanced", desc: "Jornada pós-apocalíptica pelos túneis e superfícies da Rússia devastada.", tag: "Atmosférico", genre: "fps", score: 90, price: "R$ 79,90" },
    ]
  },
  esports: {
    title: "Cenário Competitivo & E-Sports",
    color: "linear-gradient(135deg, #3c1b40, #1d0920)",
    games: [
      { id: "es-1", name: "Valorant", desc: "Mudanças de agentes no patch atual e novas táticas para o mapa competitivo.", tag: "Meta", genre: "esports", score: 90, price: "Grátis" },
      { id: "es-2", name: "Counter-Strike 2", desc: "Ajustes de sub-tick, alinhamento de granadas e novidades do próximo Major.", tag: "Competitivo", genre: "esports", score: 92, price: "Grátis" },
      { id: "es-3", name: "League of Legends", desc: "Análise completa da pré-temporada e os campeões com maior taxa de vitória.", tag: "Atualização", genre: "esports", score: 88, price: "Grátis" },
      { id: "es-4", name: "Dota 2", desc: "O MOBA mais complexo do mundo com patch recente e novos heróis.", tag: "Estratégia", genre: "esports", score: 91, price: "Grátis" },
      { id: "es-5", name: "Rocket League", desc: "Futebol com carros voadores em arenas que testam reflexos e controle.", tag: "Casual/Pro", genre: "esports", score: 89, price: "Grátis" },
    ]
  },
  terror: {
    title: "Terror e Sobrevivência",
    color: "linear-gradient(135deg, #181818, #050505)",
    games: [
      { id: "te-1", name: "Resident Evil 9: Cruel Peak", desc: "O novo capítulo de horror de sobrevivência em uma ilha isolada.", tag: "Lançamento", genre: "terror", score: 91, price: "R$ 299,90", isNew: true },
      { id: "te-2", name: "Silent Hill 2 Remake", desc: "Reviva o terror psicológico na névoa com fidelidade gráfica assustadora.", tag: "Destaque", genre: "terror", score: 88, price: "R$ 199,90" },
      { id: "te-3", name: "Dead Space (Remake)", desc: "Desmembramento estratégico a bordo da icônica e claustrofóbica USG Ishimura.", tag: "Sci-Fi", genre: "terror", score: 93, price: "R$ 179,90" },
      { id: "te-4", name: "Outlast Trials", desc: "Sobreviva a experimentos macabros sozinho ou com amigos no cooperativo.", tag: "Co-op", genre: "terror", score: 82, price: "R$ 99,90" },
      { id: "te-5", name: "Alan Wake 2", desc: "Um thriller psicológico noir que redefine o que os jogos podem ser como arte.", tag: "Psicológico", genre: "terror", score: 89, price: "R$ 219,90" },
    ]
  },
  estrategia: {
    title: "Estratégia e Simulação",
    color: "linear-gradient(135deg, #1b2640, #0a101f)",
    games: [
      { id: "st-1", name: "Civilization VII", desc: "Construa um império que resista ao teste do tempo no novo patamar de estratégia.", tag: "Novo", genre: "estrategia", score: 86, price: "R$ 259,90", isNew: true },
      { id: "st-2", name: "Age of Empires IV", desc: "Guias de ordens de construção rápidas para dominar as ranqueadas online.", tag: "RTS", genre: "estrategia", score: 84, price: "R$ 99,90" },
      { id: "st-3", name: "Cities: Skylines II", desc: "Dicas de otimização de tráfego e expansão de megacidades sem colapsar a economia.", tag: "Simulador", genre: "estrategia", score: 78, price: "R$ 149,90" },
      { id: "st-4", name: "Total War: Warhammer III", desc: "Batalhas épicas com fantasia sombria e estratégia de campanha profunda.", tag: "Tático", genre: "estrategia", score: 87, price: "R$ 179,90" },
    ]
  },
  retro: {
    title: "Preservação, Clássicos e Emuladores",
    color: "linear-gradient(135deg, #40371b, #1f1a0a)",
    games: [
      { id: "re-1", name: "Chrono Trigger HD-2D Remake", desc: "O clássico atemporal redesenhado na engine gráfica moderna.", tag: "Retro", genre: "retro", score: 98, price: "R$ 159,90" },
      { id: "re-2", name: "Super Mario World", desc: "Guias de speedrun, hacks de comunidade e configurações ideais de filtros.", tag: "Eterno", genre: "retro", price: "SNES" },
      { id: "re-3", name: "Castlevania: Symphony of the Night", desc: "O pai do gênero Metroidvania rodando em alta resolução e baixa latência.", tag: "Clássico", genre: "retro", score: 97, price: "R$ 29,90" },
      { id: "re-4", name: "RetroArch Setup 2026", desc: "O tutorial definitivo para compilar e organizar sua biblioteca retrô.", tag: "Tutorial", genre: "retro", price: "Grátis" },
    ]
  },
  indie: {
    title: "Jogos Indie e Independentes",
    color: "linear-gradient(135deg, #1b402e, #091c12)",
    games: [
      { id: "in-1", name: "Hollow Knight: Silksong", desc: "A sequência mais aguardada do gênero Metroidvania finalmente chegou.", tag: "Lançamento", genre: "indie", score: 95, price: "R$ 79,90", isNew: true },
      { id: "in-2", name: "Hades II", desc: "O roguelike mais polido da geração com narrativa procedural brilhante.", tag: "GotY", genre: "indie", score: 96, price: "R$ 99,90" },
      { id: "in-3", name: "Stardew Valley 1.6", desc: "A fazenda mais aconchegante dos games ganhou conteúdo massivo.", tag: "Relaxante", genre: "indie", score: 94, price: "R$ 29,90" },
      { id: "in-4", name: "Celeste", desc: "Plataformer desafiador com narrativa poderosa sobre saúde mental.", tag: "Aclamado", genre: "indie", score: 97, price: "R$ 49,90" },
    ]
  },
  aventura: {
    title: "Aventura e Mundo Aberto",
    color: "linear-gradient(135deg, #1a3a2a, #0a1a12)",
    games: [
      { id: "av-1", name: "The Legend of Zelda: Echoes of Wisdom", desc: "Novas mecânicas de criação e exploração no universo mais querido dos games.", tag: "Nintendo", genre: "aventura", score: 94, price: "R$ 299,90" },
      { id: "av-2", name: "Ghost of Yōtei", desc: "Retorno ao Japão feudal com uma nova protagonista e combate refinado.", tag: "PS5", genre: "aventura", score: 91, price: "R$ 299,90", isNew: true },
      { id: "av-3", name: "Horizon Forbidden West: Complete", desc: "Exploração em mundo pós-apocalíptico com máquinas dinossauro.", tag: "Exclusivo", genre: "aventura", score: 88, price: "R$ 149,90" },
      { id: "av-4", name: "Red Dead Redemption 2", desc: "O epítome do mundo aberto cinematográfico. Ainda insuperável.", tag: "Atemporal", genre: "aventura", score: 97, price: "R$ 99,90" },
    ]
  },
};

export const lancamentosData: Game[] = [
  { id: "l1", name: "Doom: The Dark Ages", desc: "A nova era do Doom Slayer com combate medieval brutal e pace mais lento.", tag: "FPS", genre: "fps", score: 93, price: "R$ 249,90", isNew: true },
  { id: "l2", name: "The Witcher 4: Polaris", desc: "CD Projekt Red inicia nova trilogia com a bruxa Ciri como protagonista.", tag: "RPG", genre: "rpg", score: 94, price: "R$ 299,90", isNew: true },
  { id: "l3", name: "Ghost of Yōtei", desc: "Novo capítulo da série Ghost of Tsushima em terras do norte do Japão.", tag: "Aventura", genre: "aventura", score: 91, price: "R$ 299,90", isNew: true },
  { id: "l4", name: "Resident Evil 9: Cruel Peak", desc: "Sobrevivência e terror em uma ilha isolada com mecânicas de crafting novas.", tag: "Terror", genre: "terror", score: 91, price: "R$ 299,90", isNew: true },
  { id: "l5", name: "Hollow Knight: Silksong", desc: "A aguardadíssima sequência do Metroidvania indie mais amado.", tag: "Indie", genre: "indie", score: 95, price: "R$ 79,90", isNew: true },
  { id: "l6", name: "Civilization VII", desc: "Reimagina completamente a progressão civilizacional com eras distintas.", tag: "Estratégia", genre: "estrategia", score: 86, price: "R$ 259,90", isNew: true },
];

export const analisesData = [
  { id: "a1", game: "Doom: The Dark Ages", reviewer: "Carlos Mendes", score: 93, resumo: "Uma reinvenção corajosa que mantém a essência brutal da série.", tag: "FPS", date: "10 Jun 2026" },
  { id: "a2", game: "Baldur's Gate 3: Year One", reviewer: "Ana Paula Costa", score: 97, resumo: "Um ano depois, ainda o melhor RPG da geração. Cada update melhora uma obra-prima.", tag: "RPG", date: "05 Jun 2026" },
  { id: "a3", game: "Alan Wake 2 (DLC Night Springs)", reviewer: "Ricardo Alves", score: 89, resumo: "Remedy continua redefinindo o thriller psicológico interativo.", tag: "Terror", date: "01 Jun 2026" },
  { id: "a4", game: "Hollow Knight: Silksong", reviewer: "Fernanda Lima", score: 95, resumo: "Valeu a espera. Team Cherry entregou uma obra ainda mais refinada.", tag: "Indie", date: "28 Mai 2026" },
  { id: "a5", game: "Ghost of Yōtei", reviewer: "Thiago Rocha", score: 91, resumo: "Sucker Punch captura novamente a beleza do Japão feudal com maestria.", tag: "Aventura", date: "20 Mai 2026" },
];

export const topVendasData: Game[] = [
  { id: "tv1", name: "GTA VI", desc: "O retorno de Rockstar ao crime de alto nível em Vice City moderna.", tag: "Open World", genre: "aventura", rank: 1, price: "R$ 349,90" },
  { id: "tv2", name: "Elden Ring: Shadow of the Erdtree", desc: "A expansão definitiva do jogo mais premiado de 2022.", tag: "GotY", genre: "rpg", rank: 2, price: "R$ 159,90" },
  { id: "tv3", name: "Doom: The Dark Ages", desc: "Doom com combate medieval. Brutal e magistral.", tag: "FPS", genre: "fps", rank: 3, price: "R$ 249,90" },
  { id: "tv4", name: "The Witcher 4: Polaris", desc: "Nova saga de Ciri já quebra recordes de pré-venda.", tag: "RPG", genre: "rpg", rank: 4, price: "R$ 299,90" },
  { id: "tv5", name: "Hades II", desc: "Supergiant Games supera a si mesma no roguelike narrativo.", tag: "Indie", genre: "indie", rank: 5, price: "R$ 99,90" },
  { id: "tv6", name: "Call of Duty: Black Ops 7", desc: "A franquia anual mais vendida volta com campanha renovada.", tag: "FPS", genre: "fps", rank: 6, price: "R$ 299,90" },
  { id: "tv7", name: "Minecraft 2", desc: "A sequência do jogo mais vendido da história com gráficos modernos.", tag: "Sandbox", genre: "indie", rank: 7, price: "R$ 199,90" },
  { id: "tv8", name: "Ghost of Yōtei", desc: "Exclusivo PlayStation vira fenômeno de vendas.", tag: "Aventura", genre: "aventura", rank: 8, price: "R$ 299,90" },
];

export const hardwareData: HardwareItem[] = [
  { id: "hw1", name: "RTX 5080 Super", desc: "A placa de vídeo mais potente da NVIDIA para 4K/144fps com Ray Tracing total.", tag: "Componentes", category: "gpu", price: "R$ 6.999,00" },
  { id: "hw2", name: "Teclados Mecânicos Custom", desc: "Guia definitivo 2026 para escolher switches Linear, Tátil ou Clicky.", tag: "Periféricos", category: "teclado", price: "a partir de R$ 299,90" },
  { id: "hw3", name: "Consoles Portáteis 2026", desc: "A evolução avassaladora dos PCs de bolso e novos lançamentos.", tag: "Plataformas", category: "console", price: "a partir de R$ 1.499,90" },
  { id: "hw4", name: "Monitor QD-OLED 360Hz", desc: "Ápice da qualidade de imagem com menor tempo de resposta para o competitivo.", tag: "Telas", category: "monitor", price: "R$ 5.499,00" },
  { id: "hw5", name: "Headsets com Áudio Espacial", desc: "Rastreamento de áudio 3D que redefine a imersão nos jogos.", tag: "Áudio", category: "headset", price: "a partir de R$ 599,90" },
  { id: "hw6", name: "Cadeiras Gamer Ergonômicas", desc: "Conforto para longas sessões de jogo com suporte lombar avançado.", tag: "Mobiliário", category: "cadeira", price: "a partir de R$ 1.299,90" },
];

export const forumPosts: ForumPost[] = [
  { id: "f1", title: "[Oficial] Procurando Grupo (LFG) - RPGs de 2026", author: "NexusBot", category: "RPG", time: "5 min atrás", replies: 142 },
  { id: "f2", title: "Campeonato Nexus Valorant Cup - Inscrições Abertas!", author: "Mod_Gamer", category: "E-Sports", time: "1 hora atrás", replies: 89 },
  { id: "f3", title: "Vale a pena trocar a RTX 4070 Ti pela nova RTX 5080?", author: "TechGamer20", category: "Hardware", time: "2 horas atrás", replies: 312 },
  { id: "f4", title: "Análise Doom: The Dark Ages - Masterpiece ou Decepção?", author: "CriticoGamer", category: "FPS", time: "3 horas atrás", replies: 67 },
  { id: "f5", title: "Setup Tour 2026: meu PC por R$ 8.000 rodando tudo", author: "PCMaster99", category: "Setups", time: "5 horas atrás", replies: 201 },
  { id: "f6", title: "The Witcher 4 vs. Elden Ring 2 - quem ganha o GotY?", author: "GameDebater", category: "RPG", time: "8 horas atrás", replies: 455 },
];

export const allSearchableItems = [
  ...lancamentosData.map(g => ({ ...g, section: "Lançamentos da Semana" })),
  ...topVendasData.map(g => ({ ...g, section: "Top Vendas" })),
  ...hardwareData.map(h => ({ id: h.id, name: h.name, desc: h.desc, tag: h.tag, genre: h.category, price: h.price, section: "Hardware" })),
  ...Object.values(gamesDatabase).flatMap(db => db.games.map(g => ({ ...g, section: db.title }))),
];
