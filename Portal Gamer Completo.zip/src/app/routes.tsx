import { createBrowserRouter } from "react-router";
import Login from "./pages/Login";
import Cadastro from "./pages/Cadastro";
import Home from "./pages/Home";
import Consoles from "./pages/Consoles";
import PCGaming from "./pages/PCGaming";
import Perifericos from "./pages/Perifericos";
import Jogos from "./pages/Jogos";
import GenrePage from "./pages/GenrePage";

export const router = createBrowserRouter([
  { path: "/", Component: Login },
  { path: "/cadastro", Component: Cadastro },
  { path: "/home", Component: Home },
  { path: "/consoles", Component: Consoles },
  { path: "/pc-gaming", Component: PCGaming },
  { path: "/perifericos", Component: Perifericos },
  { path: "/jogos", Component: Jogos },
  { path: "/genero/:genreKey", Component: GenrePage },
]);
