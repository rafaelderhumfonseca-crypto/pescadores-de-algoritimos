
  # Portal Gamer Completo

  This is a code bundle for Portal Gamer Completo. The original project is available at https://www.figma.com/design/mwao2IPRydcNvPR8mClWID/Portal-Gamer-Completo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  